import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.name}>Murillo</Text>
      <Image
        source={require('./assets/Bumblebee.jpg')}
        style={styles.image}
        accessibilityLabel="Imagem do Bumblebee"
      />
      <Text style={styles.heading}>Bumblebee é um personagem fictício dos Transformers, um grupo de robôs alienígenas que se transformam em veículos. Ele é um Autobot, um subgrupo benigno dos Transformers, que se opõe aos Decepticons, o subgrupo maligno. </Text>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: {
    color: 'yellow',
    fontSize: 20, // Tamanho da fonte
    marginBottom: 10, // Espaçamento abaixo do texto
  },
  heading: {
    color: 'yellow',
    fontSize: 16, // Tamanho da fonte do título
    marginTop: 10, // Espaçamento acima do texto
  },
  image: {
    width: 200,
    height: 200, // Altura da imagem para manter a proporção
    resizeMode: 'contain' // Garante que a imagem caiba dentro do espaço definido
  },
});
